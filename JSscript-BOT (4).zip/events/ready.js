module.exports = (client) => {
  console.log('logado' + client.user.tag)
}