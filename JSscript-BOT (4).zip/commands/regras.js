const Discord = require('discord.js')
const button = require('discord-buttons')

exports.run = async(client, message, args) => {

const embed = new Discord.MessageEmbed()
         .setColor("black")
         .setTitle('Regras do bot!')
         .setDescription('Leia com atencao as regras para nao levar blacklist do bot!!!                                 1•Regra:                    Nao usar o say para mas intencoes lembre-se que no terminal posso ver tudo oque vc faz.                                                   2•Regra:                     Proibido conteudo +18 no comando de tocar ou no de youtube nao disponivel ainda.                              3•Regra:                     Nao tentar travar o bot (Rate limit) isso pode te levar a blacklist tmb.                                            4•Regra:                     Nao tentar derrubar o bot pois vou ver no terminal e posso te dar blacklist por id.')
         .setFooter('Regras feita pelo criador :D')
         .setTimestamp(new Date)
         
let button1 = new button.MessageButton()
          .setLabel("Concordo")
          .setID("button1")
          .setStyle("green")
          
let button2 = new button.MessageButton()
          .setLabel("Discordo")
          .setID("button2")
          .setStyle("red")
   
let row1 = new button.MessageActionRow()
      .addComponent(button1)
      .addComponent(button2)

message.channel.send(embed, {component: row1})
}