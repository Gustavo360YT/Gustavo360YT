module.exports = {name: "ferinha",author: "ferinha",run: async(message) => {message.channel.send()}}
