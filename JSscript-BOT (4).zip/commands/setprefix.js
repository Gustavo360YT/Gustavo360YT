const db = require('quick.db');

module.exports = {
	name: 'setprefix',
	description: 'Usado para setar um novo prefixo ',
	aliases: ['sp', 'setprefixo', 'newprefix', 'newprefixo'],
	usage: '[novo prefixo]',
	cooldown: 5,
	async execute(client, message, args) {
			
	  if(!message.member.permissions.has("MANAGE_GUILD")) {
	    return message.channel.send(`**${message.author} você precisa da permissão \`gerenciar_servidor\` para executar este comando**`)
	  }
	  
	  let msg = args.join("");
	  let usado = await db.get(`config.${message.guild.id}.prefixo`) || "m.";
	  
	  if(!msg) {
	    return message.channel.send(`**${message.author} você esqueceu de dizer qual sera o novo prefixo\ntente assim: \`${usado}setprefix [novo prefixo]\`**`)
	  }
	  
	  if(msg === usado) {
	    return message.channel.send(`**${message.author} este prefixo ja esta sendo usado, tente usar outro!**`)
	  }
	  
	  if(msg.length > 3) {
	    return message.channel.send(`**${message.author} o prefixo não pode ser maior que 3 caracteres**`)
	  } else {
	    
	    db.set(`config.${message.guild.id}.prefixo`, msg);
	    message.channel.send(`**Sucesso!, o meu novo prefixo neste servidor agora e \`${msg}\`**`)
	  }
	},
};
