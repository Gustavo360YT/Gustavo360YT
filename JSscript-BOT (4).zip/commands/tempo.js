const cooldowns = {}
const ms = require("ms")

module.exports.run = async (client, message, args) => {

if(!cooldowns[message.author.id]) cooldowns[message.author.id] = {
    lastCmd: null
  }
let ultimoCmd = cooldowns[message.author.id].lastCmd 
 let timeout = 4000
if (ultimoCmd !== null && timeout- (Date.now() - ultimoCmd) > 0) {
let time = ms(timeout - (Date.now() - ultimoCmd)); 
let resta = [time.seconds, 'segundos']

if(resta[0] == 0) resta = ['alguns', 'millisegundos']
if(resta[0] == 1) resta = [time.seconds, 'segundo']
message.channel.send(`**Por favor ${message.author}, espere **\`${time}\`** para executar outro comando**`).then(msg=> {
    msg.delete({ timeout: 5000 });
    })
   return;
} else {
    cooldowns[message.author.id].lastCmd = Date.now() 
}}