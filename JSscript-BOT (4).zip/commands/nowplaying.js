module.exports= {
name: "nowplaying",
aliases: "np",
code: `
$description[$author[Now playing;https://cdn.discordapp.com/emojis/729630163750354955.gif?size=1024]
$title[$songInfo[title]]
$addField[Duration;$songInfo[duration]]
$addField[URL;$songInfo[url]]]
$footer[$botPingms para carregá-lo.]
$thumbnail[$songInfo[thumbnail]]
$color[a09fff]

$onlyIf[$queueLength!=0;Nenhuma música estava tocando.]
$onlyIf[$voiceID!=;Você precisa entrar no canal de voz primeiro!]`
}