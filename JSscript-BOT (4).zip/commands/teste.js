const Discord = require("discord.js")
const disbut = require("discord-buttons")

exports.run = async (client, message, args) => {

    let button = new disbut.MessageButton()
          .setLabel("teste")
          .setID("id")
          .setStyle("red")//cores que suporta blurple, gray, green e red 

    message.channel.send("teste", button)


}