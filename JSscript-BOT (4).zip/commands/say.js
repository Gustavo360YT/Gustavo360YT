const Discord = require('discord.js');
const cooldowns = {}
const ms = require("ms")

module.exports.run = async (client, message, args) => {
  const sayMessage = args.join(' ');
  message.delete().catch(O_o => {});
  message.channel.send(sayMessage);
};
