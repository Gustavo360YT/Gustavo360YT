
const Discord = require("discord.js");

module.exports = {
name: "membercount",
run: async (client, message, args) => {

const embed = new Discord.MessageEmbed()
.setTitle(`**😄 Quantidade De Membros Desse Servidor:**`)
.setDescription(`👉 ${message.author.username}, Neste Momento Este 
Servidor Tem ${message.guild.memberCount} Membros!`)
.setFooter(`• Autor: ${message.author.tag}`)
.setColor('#FAF8F7')
    message.channel.send(embed)
  }
};