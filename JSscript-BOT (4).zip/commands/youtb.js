const { Client, msg } = require("discord.js");
const Discord = require('discord.js');
const fetch = require('node-fetch');

module.exports = {
  name: "youtube",
  aliasses: ["yt"],

  run: async (client, msg, args) => {

    let channel = msg.member.voice.channel;

    if (!channel) return msg.channel.send('Voce precissa estar em um canal de voz para ultilizar este comando.');

    fetch(`https://discord.com/api/v8/channels/${channel.id}/invite`, {
      method: "POST",
      body: JSON.stringify({
        max_age: 86400,
        max_users: 0,
        target_aplicatiom_id: "755600276941176913",
        target_type: 2, 
        temporary: false,
        validate: null 
      }),
      headers: {
        "Athorization": `bot ${client.token}`,
        "Content -Type": "application/json"
      }
    }).then(txt => txt.json()).then(inv => {

      if (!inv.code) return msg.channel.send('erro ao iniciar youtube.')

      const embed = new Discord.MessageEmbed()
      .setTitle('youtube')
      .setcolor('#00000')
      .setDescription('TESTE para abrir o youtube clique [aqui](https://discord.com/invite/${inv.code})')

      msg.channel.send(embed)
    })
  }
}