const config = {
  prefix:'J!'
}
module.exports = config;